package com.orange.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.orangehrm.base.Base;

public class Candidate extends Base{

	@FindBy(id = "addCandidate_firstName") WebElement fname;
	@FindBy(id = "addCandidate_lastName") WebElement lname;
	@FindBy(id = "addCandidate_email") WebElement email;
	@FindBy(id = "btnSave") WebElement save;
	@FindBy(id = "btnBack") WebElement back;

	public AddCandidatePage() {
		PageFactory.initElements(driver, this);

	}

	public void addCandidate() {
		fname.sendKeys("testFname");
		lname.sendKeys("testLname");
		email.sendKeys("test@test.com");
		save.click();
		back.click();
		
		
	}

}
