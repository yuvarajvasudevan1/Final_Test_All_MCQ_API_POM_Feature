package com.orange.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.orangehrm.base.Base;
import com.orangehrm.pages.DashboardPage;
import com.orangehrm.pages.LoginPage;

public class LoginTest extends BaseTest {

	LoginPage loginPage;
	DashboardPage dashboardpage;
	
	public LoginTest() {
		super();
	}
	
	@BeforeMethod(alwaysRun = true)
	public void beforeMethod() {
		initialization();
		loginPage = new LoginPage();
		
	}
	
	@AfterMethod(alwaysRun = true)
	public void afterMethod() {
		driver.close();
		driver.quit();
	}
	
	
	
	@Test
	public void validateLoginPage() {
		loginPage.assertLoginPageTitle();
		
	}
	
	@Test
	public void loginTestWithValidData() {
		dashboardpage = loginPage.login();
		dashboardpage.assertDashboardPageTitle();
	}
	
	
	
}
