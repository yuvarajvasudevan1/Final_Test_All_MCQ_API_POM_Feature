package Testing;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class ApiTesting {
	


//	    >===============POST CREATE=============<	
		
		@Test(priority = 1)
		public void testPostCreateUser() {
			
			System.out.println("===============Test1=============");
			
			baseURI = "https://gorest.co.in";
			
		    JSONObject reqData = new JSONObject();
		    
	        //reqData.put("name", "John");
	        //reqData.put("job", "Teacher");
	        
	        //System.out.println(reqData.toJSONString());
	        
	        given()
	            //.header("Content-Type", "application/json")
	            .header("Connection", "keep-alive")
	            .contentType(ContentType.JSON)
	            .accept(ContentType.JSON)
	            .body(reqData.toJSONString())
	       .when()
	            .post("/public/v1/users")
	        .then()
	            
	            .log().all()
	            .log().body();
		}
		
		@Test (priority = 2,enabled = true)
		public void testGetuserdetail() {
			
			System.out.println("===============Test2=============");
			
			baseURI = "https://gorest.co.in";
//			Response rsp = get("https://reqres.in/api/users?page=2");
			
			given()
			    .get("/public/v1/posts")
		    .then()
		        //.statusCode(200)
		        .log().all();
			
		}
	
			
			
			@Test(priority = 3)
			public void testUpdateuserdetails() {
			
		System.out.println("===============Test3=============");
				baseURI = "https://gorest.co.in";
				
			    JSONObject reqData = new JSONObject();
			    
		       // reqData.put("name", "John");
		       // reqData.put("job", "Analyst");
		        
		       // System.out.println(reqData.toJSONString());
		        
		        given()
		           // .header("Content-Type", "application/json")
		            .header("Connection", "keep-alive")
		            .contentType(ContentType.JSON)
		            .accept(ContentType.JSON)
		            .body(reqData.toJSONString())
		       .when()
		            .put("/public/v1/comments")
		        .then()
		           // .statusCode(200)
		            .log().body();
			}	
			
			@Test(priority = 4)
			public void testCreatesauserpost() {
				
				System.out.println("===============Test4=============");
				
				baseURI = "https://gorest.co.in";
				
			    JSONObject reqData = new JSONObject();
			    
		        //reqData.put("name", "John");
		        //reqData.put("job", "Teacher");
		        
		        //System.out.println(reqData.toJSONString());
		        
		        given()
		            //.header("Content-Type", "application/json")
		            .header("Connection", "keep-alive")
		            .contentType(ContentType.JSON)
		            .accept(ContentType.JSON)
		            .body(reqData.toJSONString())
		       .when()
		            .post("/public/v1/users/100/posts")
		        .then()
		            
		            .log().all()
		            .log().body();
			}
			
			@Test(priority = 5)
			public void Createsapostcomment() {
				
				System.out.println("===============Test5=============");
				
				baseURI = "https://gorest.co.in";
				
			    JSONObject reqData = new JSONObject();
			    
		        //reqData.put("name", "John");
		        //reqData.put("job", "Teacher");
		        
		        //System.out.println(reqData.toJSONString());
		        
		        given()
		            //.header("Content-Type", "application/json")
		            .header("Connection", "keep-alive")
		            .contentType(ContentType.JSON)
		            .accept(ContentType.JSON)
		            .body(reqData.toJSONString())
		       .when()
		            .post("/public/v1/posts/100/comments")
		        .then()
		            
		            .log().all()
		            .log().body();
			}
			
			@Test(priority = 6)
			public void Createsausertodo() {
				
				System.out.println("===============Test6=============");
				
				baseURI = "https://gorest.co.in";
				
			    JSONObject reqData = new JSONObject();
			    
		        //reqData.put("name", "John");
		        //reqData.put("job", "Teacher");
		        
		        //System.out.println(reqData.toJSONString());
		        
		        given()
		            //.header("Content-Type", "application/json")
		            .header("Connection", "keep-alive")
		            .contentType(ContentType.JSON)
		            .accept(ContentType.JSON)
		            .body(reqData.toJSONString())
		       .when()
		            .post("/public/v1/users/100/todos")
		        .then()
		            
		            .log().all()
		            .log().body();
			}
			
		
				
				
				@Test(priority = 7)
				public void testDeleteuser() {
	System.out.println("===============Test7=============");
					
					baseURI = "https://gorest.co.in";
					
				    JSONObject reqData = new JSONObject();
				    
			        //reqData.put("name", "John");
			        //reqData.put("job", "Analyst");
			        
			        //System.out.println(reqData.toJSONString());
			        
			        given()
			            //.header("Content-Type", "application/json")
			            .header("Connection", "keep-alive")
			            .contentType(ContentType.JSON)
			            .accept(ContentType.JSON)
			            .body(reqData.toJSONString())
			       .when()
			            .delete("/public/v1/todos")
			        .then()
			            //.statusCode(200)
			            .log().body();
				}	

			
			
		
		
	}

